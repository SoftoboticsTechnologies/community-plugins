export declare const loggerCtx = "FastrrCheckoutPlugin";
export declare const FASTRR_PLUGIN_OPTIONS: unique symbol;
/**
 * Base URLs for outbound calls to Shiprocket's Fastrr Checkout API, per the Postman docs.
 */
export declare const FASTRR_API_BASE_URLS: {
    readonly staging: "https://fastrr-api-dev.pickrr.com";
    readonly production: "https://checkout-api.shiprocket.com";
};
export declare const FASTRR_PAYMENT_METHOD_CODE = "fastrr-payment";
export declare const DEFAULT_FASTRR_SHIPPING_METHOD_CODE = "fastrr-shipping";
export declare const DEFAULT_CATALOG_PAGE_SIZE = 100;
/**
 * How long to buffer Product/ProductVariant/Collection events for the same entity before firing
 * a single consolidated outbound webhook to Fastrr, to avoid one call per variant on bulk edits.
 */
export declare const DEFAULT_CATALOG_WEBHOOK_DEBOUNCE_MS = 3000;
