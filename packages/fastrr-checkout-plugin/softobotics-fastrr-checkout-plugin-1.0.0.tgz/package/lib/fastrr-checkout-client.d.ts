import { FastrrAccessTokenRequestBody, FastrrAccessTokenResponse, FastrrCollectionWebhookPayload, FastrrOrderDetailsResponse, FastrrOrderListRequestBody, FastrrOrderListResponse, FastrrProductWebhookPayload } from './types';
/**
 * @description
 * Thin wrapper around Shiprocket's Fastrr Checkout REST API. One instance is created per request
 * with the calling Channel's own `fastrrApiKey`/`fastrrSecretKey`, since credentials are resolved
 * per-channel rather than baked into the plugin at init time.
 */
export declare class FastrrCheckoutClient {
    private readonly apiKey;
    private readonly secretKey;
    private readonly apiEnv;
    constructor(apiKey: string, secretKey: string, apiEnv?: 'staging' | 'production');
    generateAccessToken(body: FastrrAccessTokenRequestBody): Promise<FastrrAccessTokenResponse>;
    sendProductWebhook(payload: FastrrProductWebhookPayload): Promise<void>;
    sendCollectionWebhook(payload: FastrrCollectionWebhookPayload): Promise<void>;
    fetchOrderDetails(orderId: string): Promise<FastrrOrderDetailsResponse>;
    /**
     * Lists recently-placed orders by date range - used by the reconciliation job as a failsafe
     * for order webhooks that never arrive (Fastrr's own docs recommend this pattern).
     */
    listOrders(body: FastrrOrderListRequestBody): Promise<FastrrOrderListResponse>;
    private post;
}
