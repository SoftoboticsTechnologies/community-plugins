import { OrderService, RequestContextService } from '@vendure/core';
import type { Response } from 'express';
import { FastrrCheckoutService } from './fastrr-checkout.service';
import { FastrrCartItemInput, RequestWithRawBody } from './types';
export declare class FastrrCheckoutController {
    private fastrrCheckoutService;
    private requestContextService;
    private orderService;
    constructor(fastrrCheckoutService: FastrrCheckoutService, requestContextService: RequestContextService, orderService: OrderService);
    getProducts(channelToken: string, page: string | undefined, limit: string | undefined, req: RequestWithRawBody, res: Response): Promise<void>;
    getCollections(channelToken: string, page: string | undefined, limit: string | undefined, req: RequestWithRawBody, res: Response): Promise<void>;
    getProductsByCollection(channelToken: string, collectionId: string, page: string | undefined, limit: string | undefined, req: RequestWithRawBody, res: Response): Promise<void>;
    getOrderCodeByFastrrId(channelToken: string, fastrrOrderId: string, req: RequestWithRawBody, res: Response): Promise<void>;
    accessToken(channelToken: string, body: {
        items: FastrrCartItemInput[];
        redirectUrl: string;
    }, req: RequestWithRawBody, res: Response): Promise<void>;
    orderWebhookForChannel(channelToken: string, signature: string | undefined, req: RequestWithRawBody, res: Response): Promise<void>;
    orderWebhookByApiKey(apiKey: string | undefined, signature: string | undefined, req: RequestWithRawBody, res: Response): Promise<void>;
    private handleOrderWebhook;
    private createShopContext;
    private createAdminContext;
}
