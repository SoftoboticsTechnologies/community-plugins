import { Type } from '@vendure/core';
import { FastrrCheckoutPluginOptions } from './types';
/**
 * @description
 * Integrates [Fastrr Checkout by Shiprocket](https://www.shiprocket.in/) - a hosted/embeddable
 * checkout iframe - as an alternative checkout path alongside your existing storefront checkout.
 *
 * Fastrr credentials and the enabled/disabled flag are configured per-{@link Channel} (custom
 * fields `fastrrEnabled` / `fastrrApiKey` / `fastrrSecretKey`), editable from the Channel detail
 * page in the Admin UI/Dashboard - NOT passed to `.init()`, since catalog sync and outbound
 * webhooks must resolve credentials outside of any order/payment context.
 *
 * After installing, also create a `PaymentMethod` using the `fastrr-payment` handler (see
 * `fastrr-checkout.handler.ts`) - it must NOT be enabled for normal storefront checkout, since
 * it is only ever invoked programmatically from the inbound order webhook.
 *
 * @docsCategory FastrrCheckoutPlugin
 */
export declare class FastrrCheckoutPlugin {
    static options: FastrrCheckoutPluginOptions;
    /**
     * @description
     * Initialize the Fastrr Checkout plugin. Fastrr API credentials themselves live on each
     * Channel, not here. `allowedRedirectHosts` should be set to your storefront's hostname(s) -
     * without it, the access-token endpoint rejects every request (see
     * {@link FastrrCheckoutPluginOptions.allowedRedirectHosts}).
     */
    static init(options?: FastrrCheckoutPluginOptions): Type<FastrrCheckoutPlugin>;
}
