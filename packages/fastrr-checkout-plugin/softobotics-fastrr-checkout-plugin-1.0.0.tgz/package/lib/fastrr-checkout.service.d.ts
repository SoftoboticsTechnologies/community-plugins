import { OnApplicationBootstrap } from '@nestjs/common';
import { Channel, ChannelService, CollectionService, CustomerService, EntityHydrator, EventBus, Order, OrderService, ProductService, ProductVariantService, RequestContext, ShippingMethodService, TranslatorService } from '@vendure/core';
import { FastrrCheckoutClient } from './fastrr-checkout-client';
import { FastrrAccessTokenResponse, FastrrCartItemInput, FastrrCheckoutPluginOptions, FastrrCollectionListResponse, FastrrOrderWebhookPayload, FastrrProductListResponse } from './types';
export declare class FastrrCheckoutService implements OnApplicationBootstrap {
    private options;
    private channelService;
    private productService;
    private productVariantService;
    private collectionService;
    private orderService;
    private customerService;
    private shippingMethodService;
    private translator;
    private eventBus;
    private entityHydrator;
    /** In-memory debounce timers for outbound catalog webhooks, keyed by `${channelId}:${kind}:${entityId}`. */
    private readonly pendingCatalogWebhooks;
    constructor(options: FastrrCheckoutPluginOptions, channelService: ChannelService, productService: ProductService, productVariantService: ProductVariantService, collectionService: CollectionService, orderService: OrderService, customerService: CustomerService, shippingMethodService: ShippingMethodService, translator: TranslatorService, eventBus: EventBus, entityHydrator: EntityHydrator);
    /**
     * Subscribes to Product/ProductVariant/Collection change events and fans out a (debounced)
     * outbound webhook to Fastrr for whichever channels the changed entity belongs to and have
     * `fastrrEnabled`. Only channels the entity is actually assigned to are notified.
     */
    onApplicationBootstrap(): void;
    /**
     * Resolves which of the event's request-context channel (and any others the entity is
     * assigned to) have Fastrr enabled. In practice most installs only need `ctx.channel`, but
     * this also covers entities assigned to multiple channels via the Admin UI.
     */
    private getFastrrEnabledChannelsForEntity;
    /**
     * Resolves the Channel for a `:channelToken` path param and asserts Fastrr is enabled for it.
     * Used by every controller endpoint to scope work to the right channel/credentials.
     */
    resolveEnabledChannel(ctx: RequestContext, channelToken: string): Promise<Channel>;
    /**
     * Resolves the fastrr-enabled Channel whose `fastrrApiKey` matches the given key - used by the
     * channel-agnostic order-webhook route (`POST /fastrr/order-webhook`) so a single URL can be
     * registered with Shiprocket regardless of how many channels/brands you run, instead of one
     * URL per channel. Relies on Fastrr sending the `X-Api-Key` header on the inbound order
     * webhook - UNCONFIRMED against Fastrr's docs (the Postman example for this webhook shows no
     * auth headers at all), so this must be verified against real webhook traffic before relying
     * on it in production. The per-channel route (`POST /fastrr/:channelToken/order-webhook`)
     * remains available as a fallback that doesn't depend on this header.
     */
    resolveChannelByApiKey(ctx: RequestContext, apiKey: string): Promise<Channel>;
    getClientForChannel(channel: Channel): FastrrCheckoutClient;
    listProducts(ctx: RequestContext, page: number, limit: number): Promise<FastrrProductListResponse>;
    listCollections(ctx: RequestContext, page: number, limit: number): Promise<FastrrCollectionListResponse>;
    /**
     * NOTE: Collections relate to `ProductVariant`, not `Product`, and `ProductService.findAll`
     * has no built-in collection filter (that's normally done via the search index, which isn't
     * guaranteed to be enabled). This fetches all variants with their `collections` relation,
     * derives the distinct set of product ids belonging to the collection, then loads the
     * (paginated slice of) full products individually. Fine for small-to-medium catalogs; an
     * O(n) scan on every call - revisit with a proper query-builder join if this becomes a
     * bottleneck.
     */
    listProductsByCollection(ctx: RequestContext, collectionId: string, page: number, limit: number): Promise<FastrrProductListResponse>;
    private paginationOptions;
    /** Schedules (debounced) a product-changed webhook. `productId` may be a create/update/delete source. */
    scheduleProductWebhook(ctx: RequestContext, channel: Channel, productId: string): void;
    scheduleCollectionWebhook(ctx: RequestContext, channel: Channel, collectionId: string): void;
    /**
     * Sends a product-deleted / unpublished notification. Best-effort: the guide has no documented
     * delete webhook, so this reuses the product-update shape with `status: 'draft'`.
     */
    sendProductArchivedWebhook(channel: Channel, productId: string, title: string): Promise<void>;
    /**
     * NOTE: this in-memory debounce only coalesces events within a single server process. If
     * `vendure-backend` ever runs multiple replicas, this must move to a shared/JobQueue-based
     * debounce - flagged in the design doc.
     */
    private debounce;
    /**
     * `id`/`variants[].id` are coerced to Number() per Fastrr's "long data-type" requirement -
     * this assumes Vendure's default integer/bigint primary keys (see the caveat on
     * {@link FastrrProductWebhookPayload}).
     *
     * IMPORTANT: `ProductService.findAll`/`findOne` only auto-translates the top-level Product's
     * own fields (name/description) - nested relations loaded via the `relations` array
     * (variants, optionGroups, variant.options, etc.) come back as RAW, untranslated entities.
     * Reading `.name` directly off them returns `undefined` (silently dropped by JSON.stringify).
     * Every nested translatable entity below is explicitly translated via `TranslatorService`.
     */
    private toProductWebhookPayload;
    private toOptionValues;
    /** Translates a single nested Translatable entity (ProductVariant/ProductOption/ProductOptionGroup) and returns its `name`. */
    private translateName;
    private toCollectionWebhookPayload;
    generateAccessToken(ctx: RequestContext, channel: Channel, items: FastrrCartItemInput[], redirectUrl: string): Promise<FastrrAccessTokenResponse>;
    /**
     * Fastrr redirects the customer's browser to `redirectUrl` after checkout, so an unvalidated
     * caller-supplied value here is an open-redirect/phishing vector - reject anything whose
     * hostname isn't explicitly allowlisted via `FastrrCheckoutPlugin.init({ allowedRedirectHosts })`.
     * Fails closed: an empty/unconfigured allowlist rejects every request rather than allowing any.
     */
    private assertAllowedRedirectUrl;
    /**
     * Creates (or, on webhook retry, returns the existing) Vendure Order for a completed Fastrr
     * checkout. Payment settlement is handled separately by the caller via
     * `orderService.addPaymentToOrder` using the `fastrr-payment` method.
     *
     * REMAINING GAP: no Vendure ShippingMethod is set (Fastrr manages shipping selection itself,
     * `payload.shipping_plan`/`shipping_charges` reflect its choice) - if your OrderProcess
     * requires a shipping method before `ArrangingPayment`, that transition will fail until a
     * suitable "Fastrr" ShippingMethod is created and set here.
     *
     * NOT YET IMPLEMENTED: Fastrr's own docs note webhooks "may be sent more than once" (handled
     * here via `fastrrOrderId` idempotency) but also recommend a periodic reconciliation job
     * against the Order List/Details APIs (`FastrrCheckoutClient#listOrders`/`#fetchOrderDetails`)
     * as a failsafe for webhooks that never arrive at all. Not built yet.
     */
    createOrderFromWebhook(ctx: RequestContext, payload: FastrrOrderWebhookPayload): Promise<Order>;
    /**
     * Vendure's default OrderProcess requires a shipping method to be set before an order can
     * transition to `ArrangingPayment`. Fastrr handles shipping selection/pricing itself, so this
     * looks up a fixed ShippingMethod (by `code`, configurable via `shippingMethodCode` plugin
     * option, defaulting to `'fastrr-shipping'`) that must be created once in the Admin UI purely
     * to satisfy that check - it should NOT be enabled for the normal storefront checkout.
     */
    private setFastrrShippingMethod;
    private toAddressInput;
    /**
     * Fastrr's own calculated total (`total_amount_payable`, incl. its coupon/prepaid discounts
     * and shipping charges) isn't fed into Vendure's order calculation - it's logged here for
     * visibility only. A meaningful mismatch usually means Vendure-side promotions/shipping rules
     * are double-applying or missing relative to what the customer actually paid Fastrr.
     */
    private warnIfTotalsMismatch;
    findOrderByFastrrOrderId(ctx: RequestContext, fastrrOrderId: string): Promise<Order | undefined>;
}
