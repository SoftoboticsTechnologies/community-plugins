/**
 * @description
 * Computes the `X-Api-HMAC-SHA256` header Fastrr requires on every request: HMAC-SHA256 of the
 * raw JSON request body, using the merchant's secret key, encoded as Base64 - as specified in the
 * integration guide ("HMAC SHA256 in Base64").
 */
export declare function computeFastrrHmac(rawBody: string, secretKey: string): string;
/**
 * @description
 * Verifies an inbound Fastrr webhook's `X-Api-HMAC-SHA256` header against the raw request body,
 * using constant-time comparison to avoid timing attacks.
 */
export declare function verifyFastrrHmac(rawBody: string, signature: string, secretKey: string): boolean;
