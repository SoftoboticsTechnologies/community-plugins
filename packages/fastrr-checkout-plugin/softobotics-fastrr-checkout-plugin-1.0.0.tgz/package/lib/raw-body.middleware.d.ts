/**
 * Adds the raw request body to the incoming message so the order-webhook route can verify
 * Fastrr's `X-Api-HMAC-SHA256` signature against the exact bytes Fastrr signed, rather than a
 * re-serialized (and therefore potentially non-identical) JSON.stringify of the parsed body.
 */
export declare const rawBodyMiddleware: import("connect").NextHandleFunction;
